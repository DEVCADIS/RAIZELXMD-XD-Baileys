const fs = require('fs')

//========== CONFIG PRINCIPALE ==========//
global.owner = ['237699777530'] // Numéros propriétaires
global.ownernumber = '237699777530'
global.CREATOR_JIDS = [
  '237699777530@s.whatsapp.net'
];
global.ownername = '𝐑𝐀𝐈𝐙𝐄𝐋'
global.creator = "237699777530@s.whatsapp.net" // JID WhatsApp
global.DEVELOPER = ["237699777530"]
global.OWNER_NAME = "@DevRaizel"

global.BOT_NAME = "RAIZEL XMD"
global.botname = "RAIZEL XMD"
global.botName = "RAIZEL XMD"
global.creatorName = "ɴɪɴᴊᴀxx"
global.author = "ɴɪɴᴊᴀxx"

global.footer = "✨ ᴘᴏᴡᴇʀᴇᴅ ʙʏ *ᴅᴇᴠ-ʀᴀɪᴢᴇʟ* 👑"
global.version = "𝙑𝟭"
global.themeemoji = '🩸'
global.bankowner = "MOSES"
global.location = "ᴄᴀᴍᴇʀᴏᴜɴ"

//========== MÉDIAS ET LIENS ==========//
global.thumbnail = 'https://files.catbox.moe/s5u5x5.jpg'
global.gambar = "https://files.catbox.moe/is73bw.jpg"
global.link = "https://whatsapp.com/channel/0029VbAe9II6GcG5OtKeFU2F"

//========== STICKERS ==========//
global.packname = "sᴛɪᴄᴋᴇʀ"
global.author = "ʙʏ ʀᴀɪᴢᴇʟ xᴍᴅ"

//========== COMPORTEMENT ==========//
global.prefa = ['','!','.','#','&']
global.xprefix = '.'
global.status = false // true = self mode
global.autoRecording = true 
global.autoTyping = true
global.autorecordtype = true
global.autoread = false
global.anti92 = true
global.autoswview = true

//========== MESSAGES ==========//
global.onlyowner = `⛔ Seuls les propriétaires peuvent utiliser cette fonction.
Demande à ʀᴀɪᴢᴇʟ si tu veux les accès.`

global.database = `📌 Pour être ajouté dans la base de données, contacte *ʀᴀɪᴢᴇʟ*.`

global.mess = {
    wait: "```🕐 PATIENTE UN INSTANT...```",
    success: "✅ Fait avec succès.",
    on: "✅ RAIZEL XMD est actif",
    off: "❌ RAIZEL XMD est inactif",
    prem: "🔐 Cette commande est réservée aux utilisateurs *Premium*.",
    query: {
        text: "❓ Tu n’as pas mis de texte.",
        link: "❓ Il manque le lien.",
    },
    error: {
        fitur: "⚠️ Erreur dans cette fonction. Contacte dev ʀᴀɪᴢᴇʟ pour correction.",
    },
    only: {
        group: "❌ Fonction utilisable uniquement dans un *groupe*.",
        private: "❌ Fonction utilisable uniquement en *privé*.",
        owner: "⛔ Fonction réservée à *ʀᴀɪᴢᴇʟ*.",
        admin: "⛔ Tu dois être *admin du groupe*.",
        badmin: "❌ Le bot n’est pas admin, impossible d’exécuter.",
        premium: "🔐 Cette fonction est réservée aux utilisateurs premium de RAIZEL XMD.",
    }
}

global.hituet = 0
//==================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
