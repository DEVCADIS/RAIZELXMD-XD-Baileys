// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['237699777530']
global.gambar = ""
global.packname = "ᴅᴇᴠ ʀᴀɪᴢᴇʟ "
global.author = "ᴅᴇᴠ ʀᴀɪᴢᴇʟ "
global.levimenu = "ᴅᴇᴠ ʀᴀɪᴢᴇʟ "