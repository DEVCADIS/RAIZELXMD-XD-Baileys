module.exports = {
  BOT_TOKEN: '8393918747:AAGePK16zzfgGS3Q7LaToTRsPtuRNlyc6dc',  
  startupPassword: 'raizel'
};